#include "proyectil.h"

Proyectil::Proyectil()
{
    angulo = 0;
    velocidadInicial = 0;
    tiempo = 0;

    fisica = new FisicaSubmarina();

    delJugador = false;
}

void Proyectil::lanzar(float nuevaVelocidad,
                       float nuevoAngulo,
                       float nuevaX,
                       float nuevaY)
{
    velocidadInicial = nuevaVelocidad;
    angulo = nuevoAngulo;

    xInicial = nuevaX;
    yInicial = nuevaY;
}

void Proyectil::actualizar()
{
    tiempo += 0.1;

    float velocidadActual;

    velocidadActual = velocidadInicial;

    FisicaSubmarina* submarina;

    submarina =
        dynamic_cast<FisicaSubmarina*>(fisica);

    if(submarina != nullptr)
    {
        velocidadActual =
            submarina->aplicarResistencia(
                velocidadInicial,
                tiempo);
    }

    x = xInicial +
        fisica->calcularPosicionX(
            velocidadActual,
            angulo,
            tiempo);

    y = yInicial +
        fisica->calcularPosicionY(
            velocidadActual,
            angulo,
            tiempo);
}

bool Proyectil::verificarColision(float objetivoX,
                                  float objetivoY)
{
    if(x >= objetivoX - 15 &&
        x <= objetivoX + 65 &&
        y >= objetivoY - 15 &&
        y <= objetivoY + 65)
    {
        return true;
    }

    return false;
}

float Proyectil::getAngulo()
{
    return angulo;
}


float Proyectil::getVelocidadInicial()
{
    return velocidadInicial;
}

void Proyectil::setDelJugador(bool valor)
{
    delJugador = valor;
}

bool Proyectil::getDelJugador()
{
    return delJugador;
}